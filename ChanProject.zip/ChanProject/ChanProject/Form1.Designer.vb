﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        TextBox5 = New TextBox()
        TextBox6 = New TextBox()
        TextBox7 = New TextBox()
        TextBox16 = New TextBox()
        Label1 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        Button5 = New Button()
        Button6 = New Button()
        Button7 = New Button()
        Button8 = New Button()
        Button9 = New Button()
        TextBox8 = New TextBox()
        Intentos = New Label()
        TextBox9 = New TextBox()
        Borrar = New Button()
        Button10 = New Button()
        Button11 = New Button()
        Button12 = New Button()
        Label2 = New Label()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(228, 199)
        TextBox1.Name = "TextBox1"
        TextBox1.ReadOnly = True
        TextBox1.Size = New Size(35, 23)
        TextBox1.TabIndex = 0
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(284, 199)
        TextBox2.Name = "TextBox2"
        TextBox2.ReadOnly = True
        TextBox2.Size = New Size(35, 23)
        TextBox2.TabIndex = 1
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(345, 199)
        TextBox3.Name = "TextBox3"
        TextBox3.ReadOnly = True
        TextBox3.Size = New Size(35, 23)
        TextBox3.TabIndex = 2
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(414, 199)
        TextBox4.Name = "TextBox4"
        TextBox4.ReadOnly = True
        TextBox4.Size = New Size(35, 23)
        TextBox4.TabIndex = 3
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(484, 199)
        TextBox5.Name = "TextBox5"
        TextBox5.ReadOnly = True
        TextBox5.Size = New Size(35, 23)
        TextBox5.TabIndex = 4
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(551, 199)
        TextBox6.Name = "TextBox6"
        TextBox6.ReadOnly = True
        TextBox6.Size = New Size(35, 23)
        TextBox6.TabIndex = 5
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(611, 199)
        TextBox7.Name = "TextBox7"
        TextBox7.ReadOnly = True
        TextBox7.Size = New Size(35, 23)
        TextBox7.TabIndex = 6
        ' 
        ' TextBox16
        ' 
        TextBox16.Location = New Point(699, 199)
        TextBox16.Name = "TextBox16"
        TextBox16.ReadOnly = True
        TextBox16.Size = New Size(44, 23)
        TextBox16.TabIndex = 15
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(663, 207)
        Label1.Name = "Label1"
        Label1.Size = New Size(15, 15)
        Label1.TabIndex = 16
        Label1.Text = "="
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(892, 142)
        Button1.Name = "Button1"
        Button1.Size = New Size(88, 38)
        Button1.TabIndex = 17
        Button1.Text = "Inicio"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(314, 309)
        Button2.Name = "Button2"
        Button2.Size = New Size(38, 23)
        Button2.TabIndex = 18
        Button2.Text = "+"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(368, 309)
        Button3.Name = "Button3"
        Button3.Size = New Size(38, 23)
        Button3.TabIndex = 19
        Button3.Text = "-"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(433, 309)
        Button4.Name = "Button4"
        Button4.Size = New Size(38, 23)
        Button4.TabIndex = 20
        Button4.Text = "*"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' Button5
        ' 
        Button5.Location = New Point(495, 309)
        Button5.Name = "Button5"
        Button5.Size = New Size(38, 23)
        Button5.TabIndex = 21
        Button5.Text = "/"
        Button5.UseVisualStyleBackColor = True
        ' 
        ' Button6
        ' 
        Button6.Location = New Point(314, 252)
        Button6.Name = "Button6"
        Button6.Size = New Size(38, 23)
        Button6.TabIndex = 22
        Button6.UseVisualStyleBackColor = True
        ' 
        ' Button7
        ' 
        Button7.Location = New Point(368, 252)
        Button7.Name = "Button7"
        Button7.Size = New Size(38, 23)
        Button7.TabIndex = 23
        Button7.UseVisualStyleBackColor = True
        ' 
        ' Button8
        ' 
        Button8.Location = New Point(433, 252)
        Button8.Name = "Button8"
        Button8.Size = New Size(38, 23)
        Button8.TabIndex = 24
        Button8.UseVisualStyleBackColor = True
        ' 
        ' Button9
        ' 
        Button9.Location = New Point(495, 252)
        Button9.Name = "Button9"
        Button9.Size = New Size(38, 23)
        Button9.TabIndex = 25
        Button9.UseVisualStyleBackColor = True
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(901, 209)
        TextBox8.Name = "TextBox8"
        TextBox8.ReadOnly = True
        TextBox8.Size = New Size(66, 23)
        TextBox8.TabIndex = 26
        ' 
        ' Intentos
        ' 
        Intentos.AutoSize = True
        Intentos.Location = New Point(845, 217)
        Intentos.Name = "Intentos"
        Intentos.Size = New Size(50, 15)
        Intentos.TabIndex = 27
        Intentos.Text = "Intentos"
        ' 
        ' TextBox9
        ' 
        TextBox9.Location = New Point(699, 239)
        TextBox9.Name = "TextBox9"
        TextBox9.ReadOnly = True
        TextBox9.Size = New Size(44, 23)
        TextBox9.TabIndex = 28
        ' 
        ' Borrar
        ' 
        Borrar.Location = New Point(892, 255)
        Borrar.Name = "Borrar"
        Borrar.Size = New Size(75, 23)
        Borrar.TabIndex = 29
        Borrar.Text = "Button10"
        Borrar.UseVisualStyleBackColor = True
        ' 
        ' Button10
        ' 
        Button10.Location = New Point(892, 287)
        Button10.Name = "Button10"
        Button10.Size = New Size(88, 23)
        Button10.TabIndex = 30
        Button10.Text = "Borrar Todo"
        Button10.UseVisualStyleBackColor = True
        ' 
        ' Button11
        ' 
        Button11.Location = New Point(892, 328)
        Button11.Name = "Button11"
        Button11.Size = New Size(75, 23)
        Button11.TabIndex = 31
        Button11.Text = "Resolver"
        Button11.UseVisualStyleBackColor = True
        ' 
        ' Button12
        ' 
        Button12.Location = New Point(892, 357)
        Button12.Name = "Button12"
        Button12.Size = New Size(75, 23)
        Button12.TabIndex = 32
        Button12.Text = "Siguiente"
        Button12.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BorderStyle = BorderStyle.Fixed3D
        Label2.Cursor = Cursors.No
        Label2.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label2.Location = New Point(305, 45)
        Label2.Name = "Label2"
        Label2.Size = New Size(353, 34)
        Label2.TabIndex = 33
        Label2.Text = "Proyecto No.1 Reto Matematico"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1176, 671)
        Controls.Add(Label2)
        Controls.Add(Button12)
        Controls.Add(Button11)
        Controls.Add(Button10)
        Controls.Add(Borrar)
        Controls.Add(TextBox9)
        Controls.Add(Intentos)
        Controls.Add(TextBox8)
        Controls.Add(Button9)
        Controls.Add(Button8)
        Controls.Add(Button7)
        Controls.Add(Button6)
        Controls.Add(Button5)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Label1)
        Controls.Add(TextBox16)
        Controls.Add(TextBox7)
        Controls.Add(TextBox6)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents Intentos As Label
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents Borrar As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Label2 As Label
End Class
